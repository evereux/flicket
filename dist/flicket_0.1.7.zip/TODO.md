# Flicket Todo List

## High

## Medium
* lock tickets after x number of days?
* Make SECRET_KEY a randomly generate value when run_set_up is run and store it in the json file.

## Low
* add ability to filter tickets by who started them aswell as who they're assigned to.

