#! python3
# -*- coding: utf-8 -*-
#
# Flicket - copyright Paul Bourne: evereux@gmail.com

from flask import Blueprint

bp_errors = Blueprint('flicket-errrors', __name__)
