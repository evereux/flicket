#! python3
# -*- coding: utf-8 -*-#
#
# Flicket - copyright Paul Bourne: evereux@gmail.com

from flask import Blueprint

bp_api_v2 = Blueprint('bp_api_v2', __name__)

